-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2023 at 09:10 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_reservation_system_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `guest_table`
--

CREATE TABLE `guest_table` (
  `Guest_Id` int(11) NOT NULL,
  `Frst_name` varchar(30) NOT NULL,
  `Last_name` varchar(30) NOT NULL,
  `Phone` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guest_table`
--

INSERT INTO `guest_table` (`Guest_Id`, `Frst_name`, `Last_name`, `Phone`, `email`, `Address`) VALUES
(901, 'Mohamed', 'Kamau', '+2536764746', 'Mohamed@gmail.com', 'Mombassa'),
(902, 'Abd', 'elvis', '+2536756653', 'bhiladema@gmail.com', 'Mwingi'),
(903, 'Kendrick', 'Oumbuzi', '+2543343121', 'ombuzi@gmail.com', 'Karioko'),
(905, 'Aden', 'Jibreel', '+25436363729', 'bulle@gmail.com', 'kenya'),
(906, 'Dayman', 'Jibreel', '+25478963729', 'bulleadenjibril@gmail.com', 'London'),
(907, 'ombui', 'kamau', '+254798933', 'bulle@gmail.com', 'nairobi');

-- --------------------------------------------------------

--
-- Table structure for table `payments_table`
--

CREATE TABLE `payments_table` (
  `Payment_Id` int(11) NOT NULL,
  `Reservation_Id` int(11) NOT NULL,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `Amount` decimal(25,0) NOT NULL,
  `Mode_of_payment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservation_table`
--

CREATE TABLE `reservation_table` (
  `Reservation_Id` int(11) NOT NULL,
  `Guest_Id` int(11) NOT NULL,
  `Room_Id` int(11) NOT NULL,
  `CheckIn_Date` date NOT NULL DEFAULT current_timestamp(),
  `CheckOut_Date` date NOT NULL DEFAULT current_timestamp(),
  `Total_Cost` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservation_table`
--

INSERT INTO `reservation_table` (`Reservation_Id`, `Guest_Id`, `Room_Id`, `CheckIn_Date`, `CheckOut_Date`, `Total_Cost`) VALUES
(221, 901, 1, '2023-04-07', '2023-04-14', '45000'),
(222, 903, 3, '2023-04-05', '2023-04-08', '24000'),
(223, 905, 2, '2023-04-05', '2023-04-14', '27000'),
(224, 906, 2, '2023-04-07', '2023-04-13', '30000'),
(225, 907, 3, '2023-04-06', '2023-04-05', '57000');

-- --------------------------------------------------------

--
-- Table structure for table `roomavailability_table`
--

CREATE TABLE `roomavailability_table` (
  `Roomavailability_Id` int(11) NOT NULL,
  `Room_Id` int(11) DEFAULT NULL,
  `Date` date DEFAULT current_timestamp(),
  `Availability` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomavailability_table`
--

INSERT INTO `roomavailability_table` (`Roomavailability_Id`, `Room_Id`, `Date`, `Availability`) VALUES
(501, 1, '2023-04-07', 'Available'),
(502, 3, '2023-04-13', 'Not available'),
(504, 2, '2023-04-04', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `roomstypes_table`
--

CREATE TABLE `roomstypes_table` (
  `Roomtype_Id` int(11) NOT NULL,
  `Roomtype_Name` varchar(30) NOT NULL,
  `Roomtype_Description` text NOT NULL,
  `Roomtype_Ammenities` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomstypes_table`
--

INSERT INTO `roomstypes_table` (`Roomtype_Id`, `Roomtype_Name`, `Roomtype_Description`, `Roomtype_Ammenities`) VALUES
(201, 'Delluxe', 'A bed for two with a view', 'view and 24-hour room-service'),
(202, 'single', 'Single bed for one person.', ''),
(203, 'Honeymoon', 'A luxurious room for two with a view of the ocean.', 'honeymoon suite'),
(204, 'Master', 'A bed for two with a view.', 'View ,24-hour room-service ,large bed');

-- --------------------------------------------------------

--
-- Table structure for table `rooms_table`
--

CREATE TABLE `rooms_table` (
  `Room_Id` int(11) NOT NULL,
  `Room_Number` int(11) NOT NULL,
  `Room_Type` varchar(60) NOT NULL,
  `Room_Description` varchar(255) NOT NULL,
  `Price` decimal(25,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms_table`
--

INSERT INTO `rooms_table` (`Room_Id`, `Room_Number`, `Room_Type`, `Room_Description`, `Price`) VALUES
(1, 101, 'delluxe', '', '7500'),
(2, 101, 'delluxe', 'A bed for two with a view.', '8500'),
(3, 102, 'Single ', 'Single bed for one person.', '6000'),
(4, 103, 'Honeymoon Suite', 'A luxurious room for two with a view of the ocean.', '10000'),
(5, 104, 'Master SUite', 'A bed for two with a view.', '9500');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guest_table`
--
ALTER TABLE `guest_table`
  ADD PRIMARY KEY (`Guest_Id`);

--
-- Indexes for table `payments_table`
--
ALTER TABLE `payments_table`
  ADD PRIMARY KEY (`Payment_Id`);

--
-- Indexes for table `reservation_table`
--
ALTER TABLE `reservation_table`
  ADD PRIMARY KEY (`Reservation_Id`);

--
-- Indexes for table `roomavailability_table`
--
ALTER TABLE `roomavailability_table`
  ADD PRIMARY KEY (`Roomavailability_Id`);

--
-- Indexes for table `roomstypes_table`
--
ALTER TABLE `roomstypes_table`
  ADD PRIMARY KEY (`Roomtype_Id`);

--
-- Indexes for table `rooms_table`
--
ALTER TABLE `rooms_table`
  ADD PRIMARY KEY (`Room_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `guest_table`
--
ALTER TABLE `guest_table`
  MODIFY `Guest_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=908;

--
-- AUTO_INCREMENT for table `payments_table`
--
ALTER TABLE `payments_table`
  MODIFY `Payment_Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservation_table`
--
ALTER TABLE `reservation_table`
  MODIFY `Reservation_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `roomavailability_table`
--
ALTER TABLE `roomavailability_table`
  MODIFY `Roomavailability_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=505;

--
-- AUTO_INCREMENT for table `roomstypes_table`
--
ALTER TABLE `roomstypes_table`
  MODIFY `Roomtype_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;

--
-- AUTO_INCREMENT for table `rooms_table`
--
ALTER TABLE `rooms_table`
  MODIFY `Room_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
